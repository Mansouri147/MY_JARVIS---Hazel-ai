==================================
pyttsx3 - Text-to-speech x-platform
==================================

This documentation describes the pyttsx3 Python package v |release| and was rendered on |today|.

.. rubric:: Table of Contents

.. toctree::
   :maxdepth: 2

   support
   engine
   drivers



.. rubric:: Project Links

* `Project home page at GitHub`__
* `Package listing in PyPI`__
* `Documentation at ReadTheDocs`__

__ https://github.com/nateshmbhat/pyttsx3
__ http://pypi.python.org/pypi/pyttsx3
__ https://pyttsx3.readthedocs.org/